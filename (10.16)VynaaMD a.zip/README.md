# Order jadibot
# pairing and qrcode by Fokus ID
